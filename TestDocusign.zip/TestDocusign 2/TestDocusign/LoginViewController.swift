//
//  LoginViewController.swift
//  docusign-sdk-sample-swift
//
//  
//  Copyright © 2017 DocuSign. All rights reserved.
//


import DocuSignSDK
import SVProgressHUD
import UIKit


class LoginViewController: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.view.backgroundColor = .white
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // allow only portrait orientation
        let username = ProfileManager.Static.defaultUsername;
        let password = ProfileManager.Static.defaultPassword;
        let integratorKey = ProfileManager.Static.integratorKey;
        let hostUrl: URL! = ProfileManager.Static.demoHostApi;
        SVProgressHUD.show(withStatus: "Authenticating....")

        DSMManager.login(withUserId: username, password: password, integratorKey: integratorKey, host: hostUrl, completionBlock: { (err: Error?) in
            
            SVProgressHUD.dismiss();
            if err != nil {
                NSLog("Error logging in \(err?.localizedDescription)");
            } else {
                
                let viewController = TemplatesViewController()
                let appDel = UIApplication.shared.delegate as! AppDelegate
                
                let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                let nav = storyboard.instantiateInitialViewController()
                appDel.window?.rootViewController = nav
            }
        })
    }
}
