//
//  LinkedInLoginVC.swift
// SwiftyOnboarding
//
//  Created by Toseefhusen on 12/13/17.
//  Copyright © 2017 Rangam. All rights reserved.
//

import UIKit
import WebKit
import SVProgressHUD

/// A class is used for LinkedIn Login interface.
/// - Author: Toseef
class WebViewController: BaseViewController {

    var webView: WKWebView!
    @IBOutlet weak var viewContainer: UIView!
    var url: URL?
    var isFileShareEnable = false
    override func viewDidLoad() {
        super.viewDidLoad()

        configureUI()
        SVProgressHUD.show(withStatus: "Opening DocuSign...")
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        webView.frame = self.viewContainer.bounds
        startPageLoad()
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        webView.frame = self.viewContainer.bounds
    }

    /// This method is used to configure Webview and UI.
    /// - Author: Toseef
    fileprivate func configureUI() {

//        navigationController?.navigationBar.topItem?.title = ""

        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: viewContainer.bounds, configuration: webConfiguration)
        webView.navigationDelegate = self
        self.viewContainer.addSubview(webView)

//        if isFileShareEnable {
//            addShareBarItem()
//        }
    }

    /// This method adds bar button item "share" on the page
//    func addShareBarItem() {
//        let barbutton = UIBarButtonItem(barButtonSystemItem: .action) {
//            let act = UIActivityViewController(activityItems: [self.url!], applicationActivities: nil)
////            act.popoverPresentationController?.sourceView = barbutton
//            self.presentVC(vc: act)
//        }
//        barbutton.tintColor = .white
//        self.navigationItem.rightBarButtonItem = barbutton
//    }

    /// This method is used to start page load
    /// - Author: Toseef
    func startPageLoad() {

        // Create a URL request and load it in the web view.
        let request = URLRequest(url: url!)
        webView.load(request)
    }
}

// MARK: - WK Navigation Delegate method
extension WebViewController: WKNavigationDelegate {
    /// WKWebView WKNavigation Delegate method
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {

        if (navigationAction.request.url?.absoluteString.contains(ProfileManager.Static.returnUrl))! {
            let event: String = navigationAction.request.url!["event"]!
            self.showAlertConfirmation("Test Docusign", message: event, alertButtonTitles: ["ok"], alertButtonStyles: [.default]) { (indx) in
                self.navigationController?.popViewController(animated: true)
            }
            decisionHandler(.cancel)
        } else {
            decisionHandler(.allow)
        }
    }

    /// WKWebView WKNavigation Delegate method
    func webView(_ webView: WKWebView, didStart navigation: WKNavigation!) {
        print("Start Page Loading")
        self.showHud()
    }

    /// WKWebView WKNavigation Delegate method
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("Page loaded")
        self.dismissHud()
    }
    /// WKWebView WKNavigation Delegate method
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        print("Page error:\(error)")
        self.dismissHud()
    }
}

extension URL {
    subscript(queryParam:String) -> String? {
        guard let url = URLComponents(string: self.absoluteString) else { return nil }
        return url.queryItems?.first(where: { $0.name == queryParam })?.value
    }
}
