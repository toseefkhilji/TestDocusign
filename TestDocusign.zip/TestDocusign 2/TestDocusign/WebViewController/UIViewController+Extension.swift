//
//  UIViewController+Extension.swift
//  RTN
//
//  Created by Toseefhusen on 11/13/17.
//  Copyright © 2017 Rangam. All rights reserved.
//

import UIKit
import SVProgressHUD

extension UIViewController{
    
    /// This method is used to show SVProgressHUD.
    func showHud()  {
        DispatchQueue.main.async {
            SVProgressHUD.show()
        }
    }
    
    /// This method is used to dismiss SVProgressHUD.
    func dismissHud()  {
        DispatchQueue.main.async {
            SVProgressHUD.dismiss()
        }
    }
    
    func showAlert(_ title: String = "App", message : String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default) { action in
            print("You've pressed OK Button")
        }
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }

    func showAlertConfirmation(_ title: String = "Test Docusign", message: String, alertButtonTitles: [String], alertButtonStyles: [UIAlertActionStyle], completion: @escaping (Int)->Void) -> Void
    {
        let alert = UIAlertController(title: title,
                                      message: message,
                                      preferredStyle: UIAlertControllerStyle.alert)

        for title in alertButtonTitles {
            let actionObj = UIAlertAction(title: title,
                                          style: alertButtonStyles[alertButtonTitles.index(of: title)!], handler: { action in
                                            completion(alertButtonTitles.index(of: action.title!)!)

            })

            alert.addAction(actionObj)
        }

        //vc will be the view controller on which you will present your alert as you cannot use self because this method is static.
        self.present(alert, animated: true, completion: nil)
    }
}


// MARK: - Methods
public extension UIViewController {
    
    /// SwifterSwift: Assign as listener to notification.
    ///
    /// - Parameters:
    ///   - name: notification name.
    ///   - selector: selector to run with notified.
    public func addNotificationObserver(name: Notification.Name, selector: Selector) {
        NotificationCenter.default.addObserver(self, selector: selector, name: name, object: nil)
    }
    
    /// SwifterSwift: Unassign as listener to notification.
    ///
    /// - Parameter name: notification name.
    public func removeNotificationObserver(name: Notification.Name) {
        NotificationCenter.default.removeObserver(self, name: name, object: nil)
    }
    
    /// SwifterSwift: Unassign as listener from all notifications.
    public func removeNotificationsObserver() {
        NotificationCenter.default.removeObserver(self)
    }
    
}
