//
//  BaseViewController.swift
//  RTN
//
//  Created by Toseefhusen Khilji on 11/10/17.
//  Copyright © 2017 Rangam. All rights reserved.
//

import UIKit

/// This class used as Base class for UIViewController.
/// This base class contains many useful variables like defaults, isUserLoggedIn, loggedUser, appDelegate.
/// - Author: Toseef
class BaseViewController: UIViewController {


    // For StatusBar style
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return UIStatusBarStyle.default
    }

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }

    deinit {
        print("---dealloc---\(type(of: self))")
    }
}
