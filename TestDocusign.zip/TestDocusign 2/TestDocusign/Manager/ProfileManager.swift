//
//  ProfileManager.swift
//  docusign-sdk-sample-swift
//
//  
//  Copyright © 2017 DocuSign. All rights reserved.
//

import UIKit
import DocuSignSDK

let appId = "8871688"

class ProfileManager
{
    // singleton instance
    static let sharedInstance = ProfileManager()
    
    //This prevents others from using the default '()' initializer for this class.
    private init()
    {
        self.clientData = ProfileManager.Static.fakeClientData;
    }


    /*
     * Sample App Data
     * Update the values below with details from your developer sandbox account
     */
    
    struct Static
    {
        // default host api url
        static let demoHostApi: URL? = URL(string: "https://demo.docusign.net/restapi");

        // integrator key from your DS account goes here
        static let integratorKey: String = "738023ea-518c-4f2b-bc14-bc57e2c03639";

        // optionally include credentials in order to pre-populate user login info
        static let defaultUsername: String =  "priyanka.adamuthe@dogratech.com";
        static let defaultPassword: String = "priyanka@123";

        // optionally include credentials in order to pre-populate user login info
            static let uname: String =  "iOS Dev";
            static let uemail: String = "iOS@dev.com";
            static let clientId: String =  "1234";
            static let returnUrl: String = "https://ios.com/";
            static let role: String = "role";

        // keys for custom fields on template
        static let tabKey_name: String = "Name f90ac9ad-cc62-4c54-b193-96f43fe6a8dc";
        static let tabKey_address1: String = "Text 4a80e172-bec6-452f-80ff-13f2d615dee9";
        static let tabKey_address2: String = "Text b76fe825-6be9-4d63-9799-424adf8b5532";
        static let tabKey_address3: String = "Text f8ea786b-8791-40e9-81a8-bebee5c4dd26";
        static let tabKey_clientNumber: String = "Text c16a43fd-f467-40ab-846c-9c9a5d57407b";
        static let tabKey_investmentAmount: String = "Text 0dfa0ad2-6604-4065-b0ba-a08012d64ff1";
        
        // fake data used to pre-populate client info
        static let fakeClientData: Dictionary<String, String> = ["firstName":"Tom",
                                                                 "lastName":"Wood",
                                                                 "address":"726 Tennessee St",
                                                                 "city":"San Francisco",
                                                                 "state":"California",
                                                                 "country":"U.S.A.",
                                                                 "zipCode":"94107",
                                                                 "email":"tom.wood@digital.com",
                                                                 "phone":"415-555-1234",
                                                                 "clientNumber":"FA-45231-005",
                                                                 "investmentAmount":"$25,000.00"
        ];
    }

    
    // members
    private var mCurrentTemplateId: String = "";
    private var mUseOfflineFlow: Bool = false;
    private var mAttachmentUrl: URL?;
    private var mEnvelopesNeedToSync: Bool = false;
    private var clientData = Dictionary<String, String>();
    

    // MARK: Public Methods
    
    func setCurrentTemplateId(templateId: String)
    {
        self.mCurrentTemplateId = templateId;
    }
    
    
    func getCurrentTemplateId() -> String
    {
        return self.mCurrentTemplateId;
    }
    
    
    func setUseOfflineFlow(useOffline: Bool)
    {
        self.mUseOfflineFlow = useOffline;
    }


    func getUseOfflineFlow() -> Bool
    {
        return self.mUseOfflineFlow;
    }


    func setAttachmentPath(attachmentUrl: URL)
    {
        self.mAttachmentUrl = attachmentUrl;
    }
    
    
    func getAttachmentUrl() -> URL?
    {
        return self.mAttachmentUrl;
    }

    
    func setEnvelopesNeedToSync(needToSync: Bool)
    {
        self.mEnvelopesNeedToSync = needToSync;
    }
    
    
    func getEnvelopesNeedToSync() -> Bool
    {
        return self.mEnvelopesNeedToSync
    }

    
    func setClientPersonalInfo(firstName:String?, lastName:String?, address:String?, city:String?, state:String?, country:String?, zipCode:String?, email:String?, phone:String?)
    {
        self.clientData["firstName"] = firstName != nil ? firstName : "";
        self.clientData["lastName"] = lastName != nil ? lastName : "";
        self.clientData["address"] = address != nil ? address : "";
        self.clientData["city"] = city != nil ? city : "";
        self.clientData["state"] = state != nil ? state : "";
        self.clientData["country"] = country != nil ? country : "";
        self.clientData["zipCode"] = zipCode != nil ? zipCode : "";
        self.clientData["email"] = email != nil ? email : "";
        self.clientData["phone"] = phone != nil ? phone : "";
    }


    func setClientInvestmentInfo(clientNumber:String, investmentAmount:String)
    {
        self.clientData["clientNumber"] = clientNumber;
        self.clientData["investmentAmount"] = investmentAmount;
    }

    
    func getClientData() -> Dictionary<String, String>
    {
        return self.clientData;
    }
    
    
    func getClientName() -> String
    {
        return self.clientData["firstName"]! + " " + self.clientData["lastName"]!;
    }

    
    /**
     Returns Dictionary of the data that will be passed into the template
     */
    func getTemplateTabData() -> Dictionary<String,String>
    {
        var tabData = Dictionary<String, String>();
        tabData[ProfileManager.Static.tabKey_name] = self.getClientName();
        tabData[ProfileManager.Static.tabKey_address1] = self.clientData["address"];
        tabData[ProfileManager.Static.tabKey_address2] = self.clientData["city"]! + ", " + self.clientData["state"]!;
        tabData[ProfileManager.Static.tabKey_address3] = self.clientData["country"]! + " " + self.clientData["zipCode"]!;
        tabData[ProfileManager.Static.tabKey_clientNumber] = self.clientData["clientNumber"];
        tabData[ProfileManager.Static.tabKey_investmentAmount] = self.clientData["investmentAmount"];

        return tabData;
    }

}
