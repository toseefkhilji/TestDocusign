//
//  EnvelopesManager.swift
//  docusign-sdk-sample-swift
//
//  
//  Copyright © 2017 DocuSign. All rights reserved.
//

import DocuSignSDK
import Foundation
import DocuSignESign

class EnvelopesManager
{
    // singleton instance
    static let sharedInstance = EnvelopesManager()

    // DSM Envelopes Manager
    var mDSMEnvelopesManager: DSMEnvelopesManager?;
    
    let headerValue = "{\"IntegratorKey\":\"\(ProfileManager.Static.integratorKey)\", \"Username\":\"\(ProfileManager.Static.defaultUsername)\", \"Password\":\"\(ProfileManager.Static.defaultPassword)\"}"
    let headerKey = "X-DocuSign-Authentication"
    // list of template definitions
    var mEnvelopeDefinitions: [DSMEnvelopeDefinition]?;
    
    typealias templateCompletionHandler = (_ url: URL?) -> Void

    //This prevents others from using the default '()' initializer for this class.
    private init()
    {
        if (self.mDSMEnvelopesManager == nil)
        {
            self.mDSMEnvelopesManager = DSMEnvelopesManager.init();
        }
    }
    
    func createEnvelopFrom(_ template: DSMEnvelopeTemplateDefinition, completionHandler:@escaping templateCompletionHandler)  {

        let def = DSEnvelopeDefinition()
        def.emailSubject = "Test Docusign: " + template.name
        def.emailBlurb = "here goes tempalte detail"
        
        let trole = DSTemplateRole()
        trole.email = ProfileManager.Static.uemail
        trole.name = ProfileManager.Static.uname
        trole.roleName = ProfileManager.Static.role
        trole.clientUserId = ProfileManager.Static.clientId

        def.templateRoles = [trole]
        def.templateId = template.templateId
        def.status = "sent"
        
        
        let options = DSEnvelopesApi_CreateEnvelopeOptions()
        
        let apiClient = DSApiClient(baseURL: URL(string: "https://demo.docusign.net/restapi"))
        let api = DSEnvelopesApi(apiClient: apiClient)
        api?.setDefaultHeaderValue(headerValue, forKey: headerKey)
//        [envelopesApi setDefaultHeaderValue:self.testConfig.headerValue forKey:self.testConfig.headerKey];

        api?.createEnvelope(withAccountId: appId , envelopeDefinition: def, options: options) { (summary, error) in
            if summary != nil {
                debugPrint("Summury: \(summary)")
                self.createEnvelopeView(envelopeId: summary?.envelopeId ?? "", completionHandler: { (url) in
                    completionHandler(url)
                })
            }
        }
    }

    
    func createEnvelopeView(envelopeId eid:String, completionHandler:@escaping templateCompletionHandler ) {
        
        let viewRequest = DSRecipientViewRequest()
        viewRequest.returnUrl = ProfileManager.Static.returnUrl
        viewRequest.clientUserId = ProfileManager.Static.clientId
        viewRequest.userName = ProfileManager.Static.uname
        viewRequest.email = ProfileManager.Static.uemail
        viewRequest.authenticationMethod = "None";

        let apiClient = DSApiClient(baseURL: URL(string: "https://demo.docusign.net/restapi"))
        let api = DSEnvelopesApi(apiClient: apiClient)
        api?.setDefaultHeaderValue(headerValue, forKey: headerKey)

        api?.createRecipientView(withAccountId: appId, envelopeId: eid, recipientViewRequest: viewRequest) { (viewUrl, error) in
            if viewUrl != nil {
                debugPrint("Summury: \(viewUrl)")
                let vurl = URL(string: (viewUrl?.url)!)
                completionHandler(vurl)
            }
        }
    }
  
    
    func getCachedEnvelopeIds() -> [String]?
    {
        return self.mDSMEnvelopesManager?.cachedEnvelopeIds();
    }


    func syncEnvelopes() -> Void
    {
        self.mDSMEnvelopesManager?.syncEnvelopes();
    }
    
}
