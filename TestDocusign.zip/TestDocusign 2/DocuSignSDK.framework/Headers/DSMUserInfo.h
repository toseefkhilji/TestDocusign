#import <Foundation/Foundation.h>
/*!
 @class DSMUserInfo
 */
@interface DSMUserInfo : NSObject

/*! @brief TODO:Empty. */
@property(nonatomic, copy) NSString *userName;
/*! @brief TODO:Empty. */
@property(nonatomic, copy) NSString *email;
/*! @brief TODO:Empty. */
@property(nonatomic, copy) NSString *userId;
/*! @brief TODO:Empty. */
@property(nonatomic, copy) NSString *userType;
/*! @brief TODO:Empty. */
@property(nonatomic, copy) NSString *userStatus;
/*! @brief TODO:Empty. */
@property(nonatomic, copy) NSString *uri;


@end
